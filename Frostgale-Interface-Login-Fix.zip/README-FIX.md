# Frostgale — toegang en login herstellen

Kopieer de map `quartz` uit deze ZIP naar je projectroot en vervang de drie bestanden. Dit pakket hoort boven op Frostgale Relay 2.0; de Worker en D1-tabellen hoeven niet aangepast te worden.

Deze versie zet `PRIME_SIGNAL_LOST = true`, zoals gewenst. ENTER ARCHIVES blijft het bestaande signaalverlies-scherm tonen. INTERFACE opent een afzonderlijk lokaal onderhoudsscherm op `/archives#interface`, zonder Archives-dashboard erachter. TERUG NAAR START gaat naar de homepage.

INTERFACE bevat zijn eigen weergave van de bestaande PrimeAuth-login, met dezelfde accounts, sessie en API. De auth-initialisatie is ook opgenomen in `afterDOMLoaded`, met scheidende puntkomma's, zodat deze bij Quartz SPA-navigatie beschikbaar is. Sluiten van het loginpaneel houdt je binnen INTERFACE.

## Lokaal controleren

```powershell
cd 'C:\Echoes of Prime\QuartzSetup'
npx quartz build
```

Stop je huidige `wrangler dev` met Ctrl+C en start opnieuw:

```powershell
npx wrangler dev
```

Open http://127.0.0.1:8787 en vernieuw met Ctrl+F5.

1. ENTER ARCHIVES → signaalverlies-scherm.
2. Terug naar homepage → INTERFACE → Frostgale.
3. INLOGGEN → zichtbaar formulier met Gebruikersnaam en Wachtwoord.
4. Formulier sluiten → je blijft in Frostgale.
5. Inloggen met Lumi → Lumi's matrix verschijnt.
6. TERUG NAAR START → homepage, geen Archives-dashboard.

De signaalverlies-vlag blijft een expliciete buildinstelling. Deze fix verandert niet automatisch jouw handmatige campagneblokkade nadat de relay is geïnitialiseerd.

Controle uitgevoerd: TSX-transpilatie en syntax van de gecombineerde browserscripts. De gerenderde signaalverlies-variant bevat één eigen loginformulier, een INTERFACE-scherm en het signaalverlies-scherm; geen Archives-dashboard. Een echte browsertest op jouw lokale server is hier niet uitgevoerd: 127.0.0.1 verwijst hier naar een andere computer.
