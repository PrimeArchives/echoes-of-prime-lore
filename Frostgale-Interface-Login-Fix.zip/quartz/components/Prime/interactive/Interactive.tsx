import { QuartzComponent } from "../../types"
import PrimeAuth from "../PrimeAuth"

const css = String.raw`
.fr{--cyan:#69f9e1;--violet:#bb94ff;--amber:#ffcb70;--red:#ff657c;background:#030e19;color:#daf9f2;font-family:var(--codeFont,monospace);padding:18px;min-height:75vh;position:relative;isolation:isolate;overflow:hidden}.fr *{box-sizing:border-box}.fr [hidden]{display:none!important}.fr:before{content:"";position:absolute;inset:0;pointer-events:none;background:repeating-linear-gradient(0deg,transparent 0 3px,#67ffd908 3px 4px);z-index:-1}.fr-rain{position:absolute;inset:0;overflow:hidden;pointer-events:none;opacity:.12;z-index:-1;display:flex;justify-content:space-around}.fr-rain span{writing-mode:vertical-rl;color:#74ff98;letter-spacing:12px;animation:fr-fall 18s linear infinite;transform:translateY(-100%)}.fr-rain span:nth-child(2n){animation-delay:-7s}.fr-rain span:nth-child(3n){animation-delay:-13s}@keyframes fr-fall{to{transform:translateY(120vh)}}.fr-wrap{max-width:1000px;margin:auto}.fr h2{font-size:clamp(23px,5vw,38px);color:#dffff3;text-shadow:0 0 25px #5bffd34d;margin:10px 0}.fr h3{font-size:15px;color:var(--cyan);margin:0 0 12px}.fr p{font-size:12px;line-height:1.7}.fr small{font-size:11px;color:#a4c9c9}.fr-kicker{color:var(--cyan);font-size:11px;letter-spacing:.12em}.fr-panel{background:#0b1c2de8;border:1px solid #285064;border-radius:10px;padding:16px;margin:12px 0;box-shadow:inset 0 1px 0 #ffffff08}.fr-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.fr-summary>div{border:1px solid #275264;padding:12px;background:#061725}.fr-summary strong{display:block;font-size:22px;color:var(--cyan)}.fr-layout{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,1fr);gap:14px}.fr button{font:inherit;cursor:pointer;min-height:44px;color:var(--cyan);border:1px solid #35796e;background:#102f35;border-radius:6px;padding:10px}.fr button:hover{background:#18504a}.fr button:disabled{opacity:.55;cursor:default}.fr button:focus-visible{outline:3px solid var(--violet);outline-offset:2px}.fr-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:4px;margin:14px 0}.fr-grid button{position:relative;aspect-ratio:1;padding:0;min-height:44px;min-width:0;background:#06121e;border-color:#2a4054;touch-action:manipulation}.fr-grid svg{width:100%;height:100%;display:block}.fr-grid button[data-live="true"]{border-color:var(--cyan);box-shadow:0 0 12px #69f9e120;background:#10372f}.fr-grid button[data-lock="true"]{border-style:dashed;border-color:var(--amber)}.fr-grid button[data-broken="true"]{border-color:var(--red);background:#351323}.fr-grid em{position:absolute;bottom:2px;right:3px;font:9px monospace;color:#c6d9df}.fr-grid b{position:absolute;top:2px;right:3px;font-size:10px;color:var(--amber)}.fr-grid button[data-selected="true"]{outline:2px solid var(--violet);outline-offset:1px}.fr:has(.prime-auth__panel:not([hidden])){overflow:visible}.fr-circuit{padding:12px 0;border-bottom:1px solid #274252;display:grid;grid-template-columns:1fr auto;gap:6px}.fr-circuit strong{font-size:12px}.fr-circuit small{display:block;margin-top:5px}.fr-circuit meter{width:100%;height:13px;grid-column:1/-1}.fr-circuit meter::-webkit-meter-bar{background:#142631;border:0}.fr-circuit meter::-webkit-meter-optimum-value{background:#69f9e1}.fr-circuit meter::-webkit-meter-suboptimum-value{background:#ffcb70}.fr-circuit meter::-webkit-meter-even-less-good-value{background:#ff657c}.fr-diagnosis{border-left:3px solid var(--violet);padding:10px;background:#17203b;line-height:1.65;font-size:12px;margin:10px 0}.fr-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.fr-progress{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-top:10px}.fr-progress span{border:1px solid #365269;font-size:11px;text-align:center;padding:10px 2px}.fr-progress span[data-done="true"]{color:var(--cyan);border-color:var(--cyan);background:#0c352f}.fr-error{color:#ffcb70;min-height:24px;font-size:12px;line-height:1.6}.fr-log{max-height:180px;overflow:auto;white-space:pre-wrap;font-size:11px;color:#96d3b6;background:#030c13;padding:12px}.fr-status{color:var(--amber)}.fr legend{font-size:11px}.fr-dm details{padding:12px;border:1px solid #38556a;margin:8px 0}.fr-dm summary{cursor:pointer;min-height:44px;color:var(--violet)}.fr-source{display:flex;justify-content:space-between;font-size:11px;color:var(--cyan)}@media(max-width:720px){.fr-layout{grid-template-columns:1fr}.fr{padding:10px}.fr-summary>div{padding:9px 5px}.fr-summary strong{font-size:18px}.fr-panel{padding:12px}}@media(prefers-reduced-motion:reduce){.fr-rain{display:none}.fr *{animation:none!important}}`

export const interactiveAfterDOMLoaded = String.raw`
;(() => {
 if(window.__frostgale2)return;window.__frostgale2=true;
 const labels={lumi:'Lumi',clav:'Clavator',dakka:'Dakka',venn:'Venn'};
 const base=[[0,2],[0,1],[0,1,3]],coords=[[50,0],[100,50],[50,100],[0,50]];
 const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function mount(root){
  if(root.dataset.mounted)return;root.dataset.mounted='1';
  let data=null,busy=false,authVersion=0,selected=null,mode='rotate',scan=false,disposed=false,polling=false;
  const q=s=>root.querySelector(s),msg=q('[data-fr-error]');
  function view(){
   if(!data)return;
   q('[data-fr-content]').hidden=false;
   q('[data-fr-readiness]').textContent=data.readiness+'/4';
   q('[data-fr-relay]').textContent=data.online?'ONLINE':data.readiness===4?'GEREED':'OFFLINE';
   q('[data-fr-signal]').textContent=data.online?'HERSTELD':'GEEN SIGNAAL';
   q('[data-fr-pause]').textContent=data.paused?'TIMERS GEPAUZEERD':'TIMERS ACTIEF';
   q('[data-fr-progress]').innerHTML=data.progress.map(p=>'<span data-done="'+p.completed+'">'+labels[p.player]+'<br>'+ (p.completed?'Gereed':'In uitvoering')+'</span>').join('');
   q('[data-fr-player]').hidden=!data.puzzle;q('[data-fr-dm]').hidden=!data.dm;
   const p=data.puzzle;
   if(p){
    q('[data-fr-name]').textContent=labels[data.player]+' // eigen subsystem';
    q('[data-fr-free]').textContent=p.free+' PU vrij / 3 PU vereist';
    const a=p.analysis,locked=data.paused||p.completed||data.online;
    q('[data-fr-grid]').innerHTML=p.config.cells.map((c,i)=>{
     const live=a.active.includes(i),bad=c.damaged,k=data.circuits.findIndex(x=>x.id===c.motor),lock=!p.circuits[k];
     const color=bad?'#ff657c':live?'#69f9e1':'#567086';
     const ps=base[c.shape].map(d=>(d+p.rotations[i])%4);
     const pipes=ps.map(d=>'<line x1="50" y1="50" x2="'+coords[d][0]+'" y2="'+coords[d][1]+'" stroke="'+color+'" stroke-width="10"/>').join('');
     const breaks=a.breaks.filter(b=>b.i===i).map(b=>'<circle cx="'+(50+(coords[b.d][0]-50)*.8)+'" cy="'+(50+(coords[b.d][1]-50)*.8)+'" r="6" fill="#ffcb70"/>').join('');
     return '<button type="button" data-cell="'+i+'" data-live="'+live+'" data-lock="'+lock+'" data-broken="'+bad+'" data-selected="'+(selected===i)+'" aria-label="Knooppunt J-'+(i+1)+(bad?', beschadigd':lock?', motor vergrendeld':'')+'"><svg viewBox="0 0 100 100" aria-hidden="true">'+pipes+'<circle cx="50" cy="50" r="7" fill="'+color+'"/>'+breaks+(bad?'<path d="M30 30L70 70M70 30L30 70" stroke="#ff657c" stroke-width="5"/>':'')+'</svg><b>'+(lock?'🔒':'')+'</b><em>J-'+(i+1)+'</em></button>';
    }).join('');
    q('[data-fr-circuits]').innerHTML=data.circuits.map((c,k)=>{
     const v=p.conditions[k],on=p.circuits[k],status=v<=20?'KRITIEK':!on?'RISICO':v<99.9?'HERSTELLEND':'STABIEL';
     return '<div class="fr-circuit"><div><strong>'+esc(c.name)+'</strong><small>'+c.pu+' PU · '+Math.round(v)+'% · '+status+'</small><small>'+(v<50?esc(c.warning):c.id==='7g'?'Bestemming onbekend; toch actief verbruik.':'Motorvoeding beschikbaar bij inschakeling.')+'</small></div><button type="button" data-circuit="'+c.id+'" '+(locked||busy?'disabled':'')+'>'+(on?'AAN → UIT':'UIT → AAN')+'</button><meter min="0" max="100" low="50" high="80" optimum="100" value="'+v+'" aria-label="Conditie '+esc(c.name)+'"></meter></div>';
    }).join('');
    q('[data-fr-route]').textContent=a.valid?'Route verbonden — onbeschadigde stroom naar de zender.':a.faults.length?'Stroom bereikt een beschadigde leiding. Draai de aanvoer weg.':!a.active.length?'De bron bereikt J-26 niet. Verbind de ingang aan de linkerzijde.':'Route onderbroken. Amber punten tonen waar stroom niet verder kan.';
    const detail=q('[data-fr-detail]');
    if(selected!==null){const c=p.config.cells[selected],k=data.circuits.findIndex(x=>x.id===c.motor);detail.textContent='Knooppunt J-'+(selected+1)+' · Motorvoeding: '+data.circuits[k].name+' · '+(c.damaged?'Fysieke breuk; kies een omweg.':!p.circuits[k]?'Motor vergrendeld. Schakel het voedingscircuit in om te draaien.':'Motor beschikbaar. Tik in draaimodus voor 90° rechtsom.');}
    q('[data-fr-complete]').disabled=busy||locked||!a.valid||p.free<3;
    q('[data-fr-complete]').textContent=p.completed?'SUBSYSTEM GEREED':'VERGRENDEL SUBSYSTEM';
    q('[data-fr-scan]').hidden=!scan;
    q('[data-fr-scan]').textContent='Scan: '+a.active.length+' knooppunten voeren stroom. '+a.faults.length+' beschadigde leidingen onder spanning. '+(data.player==='venn'?'Choir Resonator: een onregelmatige terugkoppeling bij 7-G. De bestemming blijft onleesbaar.':'Routeer langs de fysieke breuken; geen reparatie beschikbaar.');
   }
   if(data.dm){
    const openPanels=[...q('[data-fr-dm-list]').querySelectorAll('details')].map(d=>d.open);
    q('[data-fr-dm-list]').innerHTML=data.overview.map(p=>'<details><summary>'+labels[p.player]+' · '+(p.completed?'GEREED':'IN UITVOERING')+' · '+p.free+' PU vrij</summary><p>'+p.analysis.active.length+'/30 knooppunten onder spanning · '+(p.analysis.valid?'Route verbonden':'Route onderbroken')+'</p>'+data.circuits.map((c,k)=>'<p>'+esc(c.name)+': '+Math.round(p.conditions[k])+'% · '+(p.circuits[k]?'AAN':'UIT')+'</p>').join('')+'<pre class="fr-log">'+esc(p.incidents.length?p.incidents.map(e=>new Date(e.at).toLocaleString('nl-NL')+' · '+e.message).join('\n'):'Geen kritieke incidenten geregistreerd.')+'</pre><button data-reset="'+p.player+'">Reset '+labels[p.player]+'</button></details>').join('');
    q('[data-fr-dm-list]').querySelectorAll('details').forEach((d,i)=>d.open=!!openPanels[i]);
    q('[data-fr-pause-btn]').textContent=data.paused?'HERVAT TIMERS':'PAUZEER TIMERS';
    q('[data-fr-initialize]').disabled=busy||data.readiness!==4||data.online;
   }
   q('[data-fr-mode]').textContent=mode==='rotate'?'MODUS: DRAAIEN → INSPECTEREN':'MODUS: INSPECTEREN → DRAAIEN';
  }
  async function refresh(){if(disposed||busy||polling)return;polling=true;const version=authVersion;try{const r=await fetch('/api/frostgale',{credentials:'same-origin',cache:'no-store'});const d=await r.json();if(disposed||version!==authVersion)return;if(!r.ok){data=null;q('[data-fr-content]').hidden=true;msg.textContent=d.error;return;}if(!data||d.revision>=data.revision)data=d;view();}catch{if(!disposed)msg.textContent='Geen verbinding. Acties worden pas na serverbevestiging toegepast.';}finally{polling=false;}}
  async function send(action,extra={}){if(busy||!data)return;const version=authVersion;busy=true;view();try{const r=await fetch('/api/frostgale',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,requestId:crypto.randomUUID(),...extra})});const d=await r.json();if(disposed||version!==authVersion)return;if(!r.ok)throw Error(d.error);data=d;msg.textContent='✓ '+({rotate:'Knooppunt gedraaid',toggle:'Stroomverdeling bijgewerkt',complete:'Subsystem vergrendeld; reserve gebufferd',initialize:'Frostgale Relay online. Tabletsignaal hersteld.',pause:'Timers gepauzeerd',resume:'Timers hervat',reset:'Subsystem gereset',resetAll:'Relay gereset'}[action]||'Toestand bijgewerkt');}catch(e){if(!disposed)msg.textContent=e.message;}finally{busy=false;if(!disposed){view();await refresh();}}}
  const clickHandler=e=>{const b=e.target.closest('button');if(!b||!root.contains(b)||busy)return;
   if(b.dataset.cell!==undefined){selected=Number(b.dataset.cell);view();if(mode==='rotate'&&!data.paused&&!data.online&&!data.puzzle.completed)send('rotate',{cell:selected});}
   else if(b.dataset.circuit)send('toggle',{circuit:b.dataset.circuit,on:!data.puzzle.circuits[data.circuits.findIndex(c=>c.id===b.dataset.circuit)]});
   else if(b.hasAttribute('data-fr-mode')){mode=mode==='rotate'?'inspect':'rotate';view();}
   else if(b.hasAttribute('data-fr-scan-btn')){scan=!scan;view();}
   else if(b.hasAttribute('data-fr-complete'))send('complete');
   else if(b.hasAttribute('data-fr-pause-btn'))send(data.paused?'resume':'pause');
   else if(b.hasAttribute('data-fr-initialize'))send('initialize');
   else if(b.dataset.reset&&confirm('Reset het subsystem van '+labels[b.dataset.reset]+'? De hoofdrelay gaat offline.'))send('reset',{player:b.dataset.reset});
   else if(b.hasAttribute('data-fr-reset-all')&&confirm('Alle vier puzzels, incidenten en relayvoortgang wissen?'))send('resetAll');
  };
  root.addEventListener('click',clickHandler);
  const timer=setInterval(()=>{if(!document.hidden)refresh();},1500);
  const auth=()=>{authVersion++;data=null;q('[data-fr-content]').hidden=true;refresh();};document.addEventListener('prime-auth-changed',auth);
  function cleanup(){if(disposed)return;disposed=true;clearInterval(timer);document.removeEventListener('prime-auth-changed',auth);root.removeEventListener('click',clickHandler);delete root.dataset.mounted;observer.disconnect();}
  window.addCleanup?.(cleanup);
  const observer=new MutationObserver(()=>{if(!root.isConnected){cleanup();observer.disconnect();}});observer.observe(document.body,{childList:true,subtree:true});
  refresh();
 }
 function boot(){document.querySelectorAll('[data-frostgale]').forEach(mount);}
 document.addEventListener('nav',boot);document.addEventListener('render',boot);boot();
})();
`

const Interactive: QuartzComponent = () => (
 <section class="fr" data-frostgale>
  <style dangerouslySetInnerHTML={{ __html: css }} />
  <div class="fr-rain" aria-hidden="true">{Array.from({length:16},(_,i)=><span key={i}>0101 ϟ 1100 0011 AETHER 1010 ϟ 0010 1110 0101</span>)}</div>
  <div class="fr-wrap">
   <div class="fr-kicker">PRIMEOS // BEVEILIGDE ONDERHOUDSTUNNEL</div>
   <h2>FROSTGALE RELAY</h2>
   <p>Neem de conduitmatrix over. Verbind de Aether-bron met de zender, ontwijk beschadigde leidingen en reserveer 3 PU. Vier subsystemen openen samen de hoofdrelay.</p>
   <PrimeAuth />
   <p class="fr-error" data-fr-error role="status" aria-live="polite">Beveiligde verbinding opbouwen…</p>
   <div data-fr-content hidden>
    <div class="fr-summary"><div><small>HOOFDRELAY</small><strong data-fr-relay>OFFLINE</strong></div><div><small>GEREEDHEID</small><strong data-fr-readiness>0/4</strong></div><div><small>TABLETSIGNAAL</small><strong data-fr-signal>GEEN SIGNAAL</strong></div></div>
    <div class="fr-progress" data-fr-progress />
    <p class="fr-status" data-fr-pause />
    <div data-fr-player hidden>
     <h3 data-fr-name />
     <div class="fr-layout">
      <div class="fr-panel"><h3>01 // CONDUITMATRIX · 5 × 6</h3><p>Tik om 90° rechtsom te draaien. Motoren werken alleen met hun voedingscircuit aan. Inspecteren verandert niets.</p><div class="fr-source"><span>ZENDER → rechts van J-05</span><span>BRON → links van J-26</span></div><div class="fr-grid" data-fr-grid /><small>Cyan: stroom · Grijs: inactief · Rood: breuk · Amber: motorvergrendeling / onderbreking</small><div class="fr-actions"><button data-fr-mode>MODUS: DRAAIEN</button><button data-fr-scan-btn>DIAGNOSTISCHE SCAN</button></div><div class="fr-diagnosis" data-fr-detail>Selecteer een knooppunt om de motorvoeding te inspecteren.</div><p data-fr-scan hidden /><div class="fr-diagnosis" data-fr-route /></div>
      <div class="fr-panel"><h3>02 // AETHER-VERDELING</h3><strong data-fr-free /><p>Uitschakelen maakt vermogen vrij en vergrendelt motoren. Condities dalen op de server, ook wanneer je deze pagina sluit. Inschakelen herstelt geleidelijk.</p><div data-fr-circuits /><p>Een kritieke toestand registreert een incident. De Architect bepaalt de gevolgen. Bij vergrendeling wordt de reserve gebufferd en stopt het aftellen voor dit subsystem.</p><button data-fr-complete>VERGRENDEL SUBSYSTEM</button></div>
     </div>
    </div>
    <section class="fr-panel fr-dm" data-fr-dm hidden><h3>ARCHITECT // RELAYBEHEER</h3><p>Alleen jouw account mag de hoofdrelay initialiseren. Voltooiing van vier geldige subsystemen is vereist.</p><div class="fr-actions"><button data-fr-pause-btn>PAUZEER TIMERS</button><button data-fr-initialize>INITIALISEER HOOFDRELAY</button><button data-fr-reset-all>RESET VOLLEDIGE RELAY</button></div><div data-fr-dm-list /></section>
   </div>
  </div>
 </section>
)
export default Interactive
